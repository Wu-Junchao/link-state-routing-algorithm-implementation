//
// Created by Ricardo Wu on 2021/10/28.
//

#define NodeNum 9
#include <stdbool.h>
#include <stdlib.h>
#include <stdio.h>
int** cost_graph;
int globalMyID;
int* forwarding_table;


void calculate_shortest_path()
{
    const int MAXINT = 114514;
    bool S[NodeNum];
    int dist[NodeNum];
    int prev[NodeNum];
    int i,j,t,u,res;
    for(i=0; i<NodeNum; i++)
    {
        dist[i] = cost_graph[globalMyID][i];
        S[i] = false;                                // 初始都未用过该点
        forwarding_table[i]=-1;
        if (dist[i]>0){
            prev[i] = globalMyID;
        }
        else{
            prev[i] = -1;
        }
    }

    dist[globalMyID] = 0;
    S[globalMyID] = true;
    for(i=1; i<NodeNum; i++) {
        int mindist = MAXINT;
        u=-1;         // 找出当前未使用的点j的dist[j]最小值
        for (j = NodeNum-1; j >=0; j--) {
            if (!S[j] && dist[j] > 0 && dist[j] <= mindist) {
                u = j;
                mindist = dist[j];
            }
        }                         // u保存当前邻接点中距离最小的点的号码　 　      mindist = dist[j];　　   }
        if (u==-1) {break;}//// no place to go}
        S[u] = true;
        printf("%d",u);

        for (j = NodeNum-1; j >=0; j--) {
            if (!S[j] && cost_graph[u][j] > 0 ) {
                if (dist[u] + cost_graph[u][j] < dist[j] || dist[j]<0) {
                    dist[j] = dist[u] + cost_graph[u][j];
                    prev[j] = u;
                }
                else if (dist[u] + cost_graph[u][j] == dist[j]){
                    int traceu[20];
                    int tracej[20];
                    int tu = u;
                    int tj = j;
                    int indexu=0,indexj=0;
                    while (prev[tu]!=globalMyID){
                        traceu[indexu]=tu;
                        tu = prev[tu];
                        indexu++;
                    }
                    while (prev[tj]!=globalMyID){
                        tj = prev[tj];
                        tracej[indexj]=tj;
                        indexj++;
                    }
                    indexj--;
                    indexu--;
                    while (tracej[indexj]==traceu[indexu]){
                        indexj--;
                        indexu--;
                    }
                    if (tracej[indexj]>traceu[indexu]){
                        dist[j] = dist[u] + cost_graph[u][j];
                        prev[j]=u;
                    }
                }
            }
        }
    }
    // build forwarding map
    for (i=0;i<NodeNum;i++){
        t=i;
        res=-1;
        while ( prev[t] !=-1){
            res = t;
            t=prev[t];
        }
        forwarding_table[i] =res;
    }
}

void print_graph(){
    int i,j;
    const int t = NodeNum;
    for(i = 0; i < t; i++)
    {
        printf("from %d: ",i);
        for(j = 0; j < t; j++)
        {
            printf("%d\t", cost_graph[i][j]);
        }
        printf("\n");
    }
}

void print_forwardingtable(){
    int i,j;
    const int t = NodeNum;
    for (i=0;i<t;i++){
        globalMyID = i;
        calculate_shortest_path();
        printf("Node %d fwt: ",i);
        for (j=0;j<t;j++){
            printf("%d\t",forwarding_table[j]);
        }
        printf("\n");
    }
}

int main() {
    // printf() displays the string inside quotation
    int i,j;
    forwarding_table = malloc(NodeNum*sizeof(int));
    for (i=0;i<NodeNum;i++){
        forwarding_table[i] = -1;
    }

    cost_graph = malloc(NodeNum * sizeof(int*));

    for (i=0;i<NodeNum;i++){
        cost_graph[i] = malloc(NodeNum * sizeof(int));
        for (j=0;j<NodeNum;j++){
            cost_graph[i][j] = (i==j)? 0 :-1;
        }
    }

    // construct cost graph
//    cost_graph[1][2]=1;
//    cost_graph[2][3]=1;
    cost_graph[0][8] = 555;
    cost_graph[1][2] = 54;
    cost_graph[1][5] = 2;
    cost_graph[2][1] = 54;
    cost_graph[5][1] =2;
    cost_graph[6][7] = 3;
    cost_graph[7][6] = 3;
    cost_graph[8][0] = 555;
    cost_graph[1][8]=1;
    cost_graph[1][4]=1;
    cost_graph[1][6]=1;
    cost_graph[4][7]=1;
    cost_graph[5][6]=1;
    cost_graph[2][3]=1;
    cost_graph[2][5]=1;
    cost_graph[3][4]=1;
    for (i=0;i<NodeNum;i++){
        for (j=0;j<NodeNum;j++){
            if (cost_graph[i][j]>0){
                cost_graph[j][i] = cost_graph[i][j];
            }
        }
    }


    print_graph();
    print_forwardingtable();
    return 0;
}

